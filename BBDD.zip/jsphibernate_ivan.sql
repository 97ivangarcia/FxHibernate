CREATE DATABASE jsphibernate_ivan;
-- DROP DATABASE jsphibernate_ivan;



-- proyectos
CREATE TABLE Proyecto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_proyecto VARCHAR(100) NOT NULL,
    descripcion TEXT,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE,
    estado ENUM('en curso', 'completado') NOT NULL DEFAULT 'en curso'
);

-- tareas
CREATE TABLE Tarea (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_proyecto INT NOT NULL,
    descripcion_tarea TEXT NOT NULL,
    responsable VARCHAR(100),
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE,
    estado ENUM('pendiente', 'en progreso', 'completada') NOT NULL DEFAULT 'pendiente',
    CONSTRAINT fk_proyecto
        FOREIGN KEY (id_proyecto)
        REFERENCES proyecto(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);


SELECT * FROM proyectos;
SELECT * FROM tareas;